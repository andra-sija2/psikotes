<?php 
$autoload['libraries'] = array('database', 'form_validation');
$autoload['helper'] = array('url', 'form');
?>