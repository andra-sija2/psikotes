<?php
$route['default_controller'] = 'guestbook';
$route['admin'] = 'admin';
?>