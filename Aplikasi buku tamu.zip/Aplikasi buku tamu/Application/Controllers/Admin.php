<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function index() {
        $start_date = $this->input->get('start_date');
        $end_date = $this->input->get('end_date');
        $data['entries'] = $this->Guestbook_model->get_entries($start_date, $end_date);
        $this->load->view('admin_list', $data);
    }

    public function export_csv() {
        $this->load->helper('download');
        $entries = $this->Guestbook_model->get_entries();
        $filename = 'guestbook_' . date('Ymd') . '.csv';
        $csv_data = "Nama,Email,Pesan,Tanggal\n";
        foreach ($entries as $entry) {
            $csv_data .= "\"{$entry->name}\",\"{$entry->email}\",\"{$entry->message}\",\"{$entry->created_at}\"\n";
        }
        force_download($filename, $csv_data);
    }
}
?>