<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guestbook extends CI_Controller {

    public function index() {
        $this->load->view('guestbook_form');
    }

    public function submit() {
        $this->form_validation->set_rules('name', 'Nama', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('message', 'Pesan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('guestbook_form');
        } else {
            $data = array(
                'name' => $this->input->post('name', TRUE),
                'email' => $this->input->post('email', TRUE),
                'message' => $this->input->post('message', TRUE)
            );
            $this->Guestbook_model->insert_entry($data);
            $this->session->set_flashdata('success', 'Pesan berhasil dikirim.');
            redirect('guestbook');
        }
    }
}
?>