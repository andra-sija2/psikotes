<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guestbook_model extends CI_Model {

    public function insert_entry($data) {
        return $this->db->insert('guestbook', $data);
    }

    public function get_entries($start_date = null, $end_date = null) {
        if ($start_date && $end_date) {
            $this->db->where('DATE(created_at) >=', $start_date);
            $this->db->where('DATE(created_at) <=', $end_date);
        }
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get('guestbook')->result();
    }
}
?>