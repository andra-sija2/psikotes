<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pesan</title>
</head>
<body>
    <h1>Daftar Pesan</h1>
    <form method="get" action="<?php echo base_url('admin'); ?>">
        <label>Filter Tanggal:</label>
        <input type="date" name="start_date" value="<?php echo set_value('start_date'); ?>">
        <input type="date" name="end_date" value="<?php echo set_value('end_date'); ?>">
        <input type="submit" value="Filter">
    </form>
    <p><a href="<?php echo base_url('admin/export_csv'); ?>">Export ke CSV</a></p>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Pesan</th>
            <th>Tanggal</th>
        </tr>
        <?php foreach ($entries as $entry): ?>
        <tr>
            <td><?php echo $entry->name; ?></td>
            <td><?php echo $entry->email; ?></td>
            <td><?php echo $entry->message; ?></td>
            <td><?php echo $entry->created_at; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
