<!DOCTYPE html>
<html>
<head>
    <title>Buku Tamu</title>
</head>
<body>
    <h1>Buku Tamu</h1>
    <?php if ($this->session->flashdata('success')): ?>
        <p style="color:green;"><?php echo $this->session->flashdata('success'); ?></p>
    <?php endif; ?>
    <?php echo validation_errors(); ?>
    <?php echo form_open('guestbook/submit'); ?>
        <p>
            <label>Nama:</label><br>
            <input type="text" name="name" value="<?php echo set_value('name'); ?>">
        </p>
        <p>
            <label>Email:</label><br>
            <input type="text" name="email" value="<?php echo set_value('email'); ?>">
        </p>
        <p>
            <label>Pesan:</label><br>
            <textarea name="message"><?php echo set_value('message'); ?></textarea>
        </p>
        <p><input type="submit" value="Kirim"></p>
    <?php echo form_close(); ?>
</body>
</html>
