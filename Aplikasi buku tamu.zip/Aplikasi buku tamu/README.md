# Buku Tamu Sederhana - CodeIgniter 3

Aplikasi buku tamu sederhana berbasis PHP dengan framework **CodeIgniter 3**, memungkinkan pengunjung mengisi **Nama**, **Email**, dan **Pesan** yang disimpan ke database dan dapat dilihat oleh admin.

## 📦 Fitur Utama

- Form input buku tamu (tanpa login)
- Daftar pesan di halaman admin
- Validasi input form
- Filter data berdasarkan tanggal
- Ekspor data ke CSV

## 🚀 Teknologi yang Digunakan

- PHP 5.6+ / 7+
- CodeIgniter 3.x
- MySQL / MariaDB
- HTML, CSS dasar

## 🛠️ Instalasi

1. **Clone atau copy folder ke XAMPP**:
